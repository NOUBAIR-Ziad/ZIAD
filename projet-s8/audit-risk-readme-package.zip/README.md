
# 📊 Audit Risk Analysis by Accounting Cycle

<p align="center">
<img src="photo1.png" width="180">
<img src="photo2.jpeg" width="180">
</p>

<p align="center">
<b>Audit Risk Analytics Project</b><br>
Risk Identification • Audit Assertions • Risk Matrix • Data‑Driven Auditing
</p>

---

# 📌 Project Overview

This project analyzes a structured **audit risk database classified by accounting cycles**.

The objective is to help auditors:

- identify **high‑risk accounting areas**
- evaluate **audit assertions**
- build a **risk matrix**
- support **data‑driven audit planning**

The methodology follows international auditing standards:

- ISA 315 – Identifying and Assessing Risks
- ISA 330 – Auditor's Responses to Assessed Risks

The analysis was implemented using **Python and Google Colab**.

---

# 🗂 Dataset Description

The dataset contains structured information about **audit risks across accounting cycles**.

| Column | Description |
|------|-------------|
| ID | Risk identifier |
| Cycle comptable | Accounting cycle |
| Processus | Operational process |
| Compte concerné | Related accounts (Moroccan GAAP) |
| Description du risque | Description of the audit risk |
| Type de risque | Inherent / Control / Fraud |
| Assertion impactée | Audit assertion affected |
| Niveau de risque | Risk level |
| Procédure d'audit | Recommended audit procedure |
| Documents de preuve | Supporting documents |

---

# 🔄 Accounting Cycles Covered

- Sales & Accounts Receivable
- Purchases & Accounts Payable
- Treasury
- Fixed Assets
- Inventory
- Payroll
- Taxation
- Equity

---

# ⚙️ Data Preparation

Data preprocessing steps:

- removing duplicates
- handling missing values
- cleaning text columns
- validating data types

---

# 📈 Exploratory Data Analysis

## Risk Distribution by Accounting Cycle

Identifies which cycles contain the **highest number of risks**.

## Risk Distribution by Type

| Risk Type | Description |
|------|-------------|
| Inherent Risk | Risk due to the nature of operations |
| Control Risk | Weakness in internal controls |
| Fraud Risk | Potential manipulation or misappropriation |

---

# 🔍 Audit Assertions Analysis

| Assertion | Meaning |
|------|-------------|
| Existence | Transactions actually occurred |
| Completeness | All transactions are recorded |
| Valuation | Amounts are correctly valued |
| Rights and Obligations | Assets belong to the company |
| Presentation | Financial information is properly disclosed |

---

# 📊 Risk Scoring Model

| Risk Level | Score |
|------|------|
| Low | 1 |
| Medium | 2 |
| High | 3 |

This allows:

- average risk score by cycle
- identification of risk concentration areas
- prioritization of audit procedures

---

# 🧮 Risk Matrix

A **risk matrix** was built combining:

- Accounting cycle
- Audit assertion

This helps auditors detect **risk concentration areas**.

---

# ⚠️ Fraud Risk Analysis

Examples of fraud risks:

- cash misappropriation
- fictitious invoices
- inventory manipulation
- ghost employees

These require **enhanced audit procedures**.

---

# 🛠 Technologies Used

- Python
- Pandas
- Matplotlib
- Google Colab
- Excel

---

# 📁 Project Structure

```
audit-risk-analysis/
│
├── data/
│   └── audit_risk_database.xlsx
│
├── notebooks/
│   └── audit_risk_analysis.ipynb
│
├── results/
│   └── audit_analysis_results.xlsx
│
├── photo1.png
├── photo2.jpeg
│
└── README.md
```

---

# 🎯 Conclusion

This project shows how **data analytics can enhance audit planning**
by identifying risk concentrations and supporting **evidence‑based decision making**.
